// NIM: 120140208
// Nama : Marchell Manurung
// Tanggal : 13 November 2020
// Deskripsi : Modulus

#include <iostream>
using namespace std;

int main()
{
	int m, n;

	cin >> n;

	m = n % 3;

	cout << m;

}
