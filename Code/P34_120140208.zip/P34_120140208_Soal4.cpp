//NIM:120140208
//Nama:Marchell Manurung
//Tanggal : 19 November 2020
//Deskripsi: Bentuk Palindrom

#include <iostream>
using namespace std;

int main() {
	int N;
	cin >> N;
	for (int i = 0; i < N; i++) {
		cout << i;
	}
	for (int i = N - 1; i >= 0; i--) {
		cout << i;
	}

}
